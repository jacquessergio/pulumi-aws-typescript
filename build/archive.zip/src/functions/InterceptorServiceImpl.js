'use strict';
Object.defineProperty(exports, "__esModule", { value: true });
exports.InterceptorApiIntegratorServiceImpl = void 0;
class InterceptorApiIntegratorServiceImpl {
    interceptRequest(event) {
        /**
         * Nothing to transform
         *
         */
        return event;
    }
    interceptResponse(response, request) {
        /**
         * Nothing to transform
         *
         */
        return response;
    }
}
exports.InterceptorApiIntegratorServiceImpl = InterceptorApiIntegratorServiceImpl;
//# sourceMappingURL=InterceptorServiceImpl.js.map